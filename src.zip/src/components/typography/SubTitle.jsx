const SubTitle = ({ content }) => {
  return <p className="text-sm text-gray-400 mt-1">{content}</p>;
};
export default SubTitle;
