export { default as Input2 } from './Input2';
export { default as Input } from './Input';
export { default as Input3 } from './Input3';