// import { HomeIcon, UploadIcon, UserIcon } from '@heroicons/react/outline';
// import Link from 'next/link';

// const Footerlanding = () => {
//   return (
//     // <footer className=" bg-white h-16 fixed bottom-0 left-0 w-full z-50">
//     //   <div className="max-w-md mx-auto h-full  flex justify-between items-center">
//     //     <Link href="/">
//     //       <button type="button" className="inline-flex w-16 h-full justify-center items-center flex-col border-t-4 border-cyan-500 text-cyan-500">
//     //         <HomeIcon className="w-6 h-6" />
//     //         <span className="text-sm">
//     //           Home
//     //         </span>
//     //       </button>
//     //     </Link>

//     //     <Link href="/upload">
//     //       <button type="button" className="inline-flex w-16 h-full justify-center items-center flex-col border-t-4 border-cyan-500 text-cyan-500">
//     //         <UploadIcon className="w-6 h-6" />
//     //         <span className="text-sm">
//     //           Upload
//     //         </span>
//     //       </button>
//     //     </Link>

//     //     <Link href="/account">
//     //       <button type="button" className="inline-flex w-16 h-full justify-center items-center flex-col border-t-4 border-cyan-500 text-cyan-500">
//     //         <UserIcon className="w-6 h-6" />
//     //         <span className="text-sm">
//     //           Account
//     //         </span>
//     //       </button>
//     //     </Link>

//     //   </div>
//     // </footer>

//     <footer className="text-gray-600  ">
//       <div className="container px-5 py-24 mx-auto flex md:items-center lg:items-start md:flex-row md:flex-nowrap flex-wrap flex-col">
//         <div></div>
//         <div className="w-[389px] flex-shrink-0 md:mx-0 mx-auto text-center md:text-left">
//           <a className="flex title-font font-medium items-center md:justify-start justify-center text-gray-900">
//             <img src="Logo Header.svg" className="  w-full pl-3"></img>
//           </a>
//         </div>
//         <div className="flex-grow flex justify-between flex-wrap md:pl-20 -mb-10 md:mt-0 mt-10 md:text-left text-center">
//           <div className="lg:w-1/4 md:w-1/2 w-full px-4">
//             <h2 className="title-font font-semibold tracking-widest text-[#00229B] text-xl mb-3">FEATURES</h2>
//             <nav className="list-none mb-10">
//               <li>
//                 <a href="../" className=" text-[#00229B] text-lg ">Simpler</a>
//               </li>
//               <li>
//                 <a href="../" className="text-[#00229B] text-lg ">My Chance</a>
//               </li>
//             </nav>
//           </div>
//           <div className="lg:w-1/4 md:w-1/2 w-full px-4">
//             <h2 className="title-font   tracking-widest text-[#00229B] text-xl font-semibold mb-3">COMMUNITY</h2>
//             <nav className="list-none mb-10">
//               <li>
//                 <a href="../" className="text-[#00229B] text-lg ">About Us</a>
//               </li>
//             </nav>
//           </div>
//           <div className="lg:w-1/4 md:w-1/2 w-full px-4">
//             <h2 className="title-font  tracking-widest  text-[#00229B] text-xl font-semibold mb-3">SUPPORT</h2>
//             <nav className="list-none mb-10">
//               <li>
//                 <a href="../" className="text-[#00229B] text-lg ">Privacy Policy</a>
//               </li>
//               <li>
//                 <a href="../" className="text-[#00229B] text-lg ">Contact Us</a>
//               </li>
//             </nav>
//           </div>
//         </div>
//       </div>
//       <div className="bg-white pt-10 pb-16  flex items-center text-center justify-center ">
//         <p className=" text-sm text-center sm:text-left">
//           <a href="#" rel="noopener noreferrer" className=" text-xl font-bold ml-1 text-[#00229B]  text-center">
//             © 2022 - Commit. All Rights Reserved
//           </a>
//         </p>
//       </div>
//     </footer>
//   );
// };

// export default Footerlanding;
