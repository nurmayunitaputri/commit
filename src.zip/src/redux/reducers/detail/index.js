export { default } from './slice';
export { useDetailDispatcher } from './slice';