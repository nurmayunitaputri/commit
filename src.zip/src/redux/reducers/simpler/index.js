export { default } from './slice';
export { useSimplerDispatcher } from './slice';