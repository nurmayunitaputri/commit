export { default } from './slice';
export { useInterestDispatcher } from './slice';