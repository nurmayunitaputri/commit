// localStorage.getItem('email')
        // localStorage.getItem('password')
        // localStorage.getItem('name')
        // localStorage.getItem('phone_number')
        // localStorage.getItem('emaildomicile')
        // localStorage.getItem('gender')
     
        // interest: values.interests