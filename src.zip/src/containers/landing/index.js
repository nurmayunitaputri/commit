export { default } from './landing';
