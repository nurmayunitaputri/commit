describe('App Testing', () => {
  test('penjumlahan 5 + 5 = 10', () => {
    const a = 5;
    const b = 5;
    expect(a + b).toBe(10);
  });
});
